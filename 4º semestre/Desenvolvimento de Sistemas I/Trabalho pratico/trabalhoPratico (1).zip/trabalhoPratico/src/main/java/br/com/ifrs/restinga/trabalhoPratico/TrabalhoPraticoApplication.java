package br.com.ifrs.restinga.trabalhoPratico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhoPraticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhoPraticoApplication.class, args);
	}

}
