package br.com.ifrs.restinga.fifa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoPraticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
