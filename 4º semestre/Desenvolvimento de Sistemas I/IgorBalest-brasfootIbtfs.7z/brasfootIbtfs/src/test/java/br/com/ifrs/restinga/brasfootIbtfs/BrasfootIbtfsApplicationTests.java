package br.com.ifrs.restinga.brasfootIbtfs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrasfootIbtfsApplicationTests {

	@Test
	void contextLoads() {
	}

}
