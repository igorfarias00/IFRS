package br.com.ifrs.restinga.brasfootIbtfs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrasfootIbtfsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrasfootIbtfsApplication.class, args);
	}

}
