package avlTree;

public class No {
	int elemento;
	No filhoEsquerda;
	No filhoDireita;
	int balanceamento;

	
}
