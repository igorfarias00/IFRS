package integracaoV1;

public class main {
	public static void main(String[] args) throws Exception {
		
		// para fazer a inserção nas chaves estrangeiras é necessario que existam os campos na tabela 
		Professor p1 = new Professor();
		Professor p2 = new Professor();
		
		p1.id = 1;
		p1.nome = "Sebastiao";
		p1.matricula = 12351;
		p1.numero = 21341;
		p1.complemento = "Rua da graça";
		p1.salario = 4330.34;
		p1.nivel_formacao = "POS DOC";
		p1.Telefone_id = 33;				// FK
		p1.Endereco_id = 12;				// FK
		p1.Coordenador = false;
		
		p1.inserir();
		
		p1.consultar();
		
		
		p1.nome = "Melo";
		p1.numero = 21341;
		p1.complemento = "Rua da desgraça";
		p1.salario = 4330.34;
		p1.nivel_formacao = "pedreiro";
		p1.Telefone_id = 33;				// FK
		p1.Endereco_id = 12;				// FK
		p1.Coordenador = true;
		
		
		p1.id = 16;
		p1.atualizar();
		
		p1.excluir();
		
		p1.inserir();
		                
		//p2.inserir();
	}
}
