package aula7_07;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner tcl = new Scanner(System.in);
		int vetor[] = new int[10];
		
		int novaCapacidade = 0;
		Caminhao c1 = new Caminhao("Volvo", "VL301", 2021, 6 , 3300);
		
		for(int i= 0; i < vetor.length; i++) {
			System.out.print(vetor[i] +" - ");
		}
		System.out.println();
		
		
		c1.info();
		System.out.println();
		c1.setCapacidade(5000);
		
		c1.info();
		System.out.println();
		System.out.println("Digita a nova capacidade:"  );
		novaCapacidade = tcl.nextInt();
		c1.setCapacidade(novaCapacidade);
		
		System.out.println();
		c1.info();
		
	}
}
