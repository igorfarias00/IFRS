package aula7_07;

public class VeiculoMaritmo extends Veiculo{
	private int codigo;
	private String empresa;
	
	
	public void compra(String novaEmpresa) {
		this.setEmpresa(novaEmpresa);
		System.out.println("Empresa atualizada com sucesso!");
	}
	
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
}
