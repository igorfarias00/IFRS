package aula7_07;

public class VeiculoTerrestres extends Veiculo{
	private int ano_fab;
	private int placa;
	private String dono;
	
	public VeiculoTerrestres(String fabricante, String modelo, int ano_fab) {
		this.setFabricante(fabricante);
		this.setModelo(modelo);
		this.setAno_fab(ano_fab);
	}
	
	public void emplacamento(int placa) {
		if(placa > 0) {
			System.out.println("placa cadastrada");
			this.setPlaca(placa);
		}else {
			System.out.println("Placa inválida");
		}
	}
	
	public void setPlaca(int placa) {
		this.placa = placa;
	}
	
	public void compra(String dono) {
		this.setDono(dono);
		System.out.println("Dono atualizado!");
	}
	
	public void setDono(String dono){
		this.dono = dono;
	}
	
	
}
