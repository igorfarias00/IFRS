package aula7_07;

public class Veiculo {
	private String fabricante;
	private String modelo;
	private String pais;
	private int posX;
	private int posY;
	private double valor;
	private int numPassageiros;
	private int ano_fab;
	
	public Veiculo() {
		
	}
	
	void deslocamento() {
		
	}
	
	public String getFabricante() {
		return fabricante;
	}
	
	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}
	
	public String getModelo() {
		return modelo;
	}
	
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public void setAno_fab(int ano) {
		this.ano_fab = ano;
	}
	
	public int getAno_fab() {
		return ano_fab;
	}
	

	public void info() {
		System.out.print("Fab/Mod: "+ this.getFabricante() + " / " + this.getModelo());
	}
}
