package aula7_07;

public class Caminhao extends VeiculoTerrestres{
	private int quant_eixos, capacidade;
	
	public Caminhao(String fabricante, String modelo, int ano_fab, int quant_eixos, int capacidade) {
		super(fabricante, modelo, ano_fab);
		this.setQuant_eixos(quant_eixos);
		this.setCapacidade(capacidade);
	}

	public int getQuant_eixos() {
		return this.quant_eixos;
	}

	public void setQuant_eixos(int quant_eixos) {
		this.quant_eixos = quant_eixos;
	}
	
	public void setCapacidade(int valor) {
		this.capacidade = valor;
	}
	
	public int getCapacidade() {
		return this.capacidade;
	}
	
	@Override
	public void info() {
		System.out.print("Fab/Mod: "+ this.getFabricante() + " / " + this.getModelo() + "\n");
		System.out.println("Ano de fabricação: " + this.getAno_fab());
		System.out.println("Quantidade de eixos: " + this.getQuant_eixos());
		System.out.println("Capacidade de carga: " + this.getCapacidade());
	}
	
}
