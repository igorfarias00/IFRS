package aula7_07;

public class VeiculoAereo extends Veiculo{
	private int codigo;
	private int posZ;
	private String empresa;
	
	@Override
	public void deslocamento() {
		
	}
	
	public void compra(String novaEmpresa) {
		this.setEmpresa(novaEmpresa);
	}
	
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
}
