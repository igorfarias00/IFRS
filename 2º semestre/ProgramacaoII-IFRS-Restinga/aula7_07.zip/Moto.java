package aula7_07;

public class Moto {

}
